import React, { Component } from 'react';

class Smart  extends Component {
    render(){
        return(
            <div className="smart">
            <h1>{this.props.paraText}</h1>
            </div>
        )
    }

}

export default Smart