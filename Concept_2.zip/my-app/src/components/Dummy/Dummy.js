import React from 'react';

const Dummy = props =>{
    return(
        <div>
            <p>{props.paraText}</p>
            <span>Hello</span>
        </div>
    )
}

export default Dummy