import React, {Component} from 'react';

class Footer extends Component{
  //Set up deeper levels of states to store data


  render(){
    return(
        <div>
            
        </div>
    )
   }
}

export default Footer;

const styles = {
  container: {}
}
